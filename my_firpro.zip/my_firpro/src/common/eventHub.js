import wepy from '@wepy/core';

let eventHub = new wepy();
console.log('eventHub',eventHub);

export default eventHub;
