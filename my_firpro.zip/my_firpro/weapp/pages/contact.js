"use strict";

var _core = _interopRequireDefault(require('../vendor.js')(1));

var _eventHub = _interopRequireDefault(require('../common/eventHub.js'));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_core["default"].page({
  config: {},
  data: {},
  computed: {},
  methods: {}
}, {info: {"components":{"list":{"path":"..\\components\\wepy-list"}},"on":{}}, handlers: {}, models: {} });