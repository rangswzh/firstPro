"use strict";

var _core = _interopRequireDefault(require('../vendor.js')(1));

var _eventHub = _interopRequireDefault(require('../common/eventHub.js'));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_core["default"].page({
  config: {},
  data: {
    array: [{
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '热卖爆款'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '蔬菜豆制品'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '水果'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '肉禽蛋'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '水产海鲜'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '粮油干调'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '方便速食'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '酒水乳饮'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '休闲零食'
    }, {
      imageurl: 'http://www.runoob.com/try/demo_source/paris.jpg',
      message: '日用百货'
    }],
    itemizeT: [{
      itemizeHref: 'https://www.baidu.com',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '热卖爆款'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '蔬菜豆制品'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '水果'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '肉禽蛋'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '水产海鲜'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '粮油干调'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '方便速食'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '酒水乳饮'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '休闲零食'
    }, {
      itemizeHref: '',
      itemizeUrl: 'https://www.runoob.com/try/demo_source/paris.jpg',
      itemizeName: '日用百货'
    }]
  },
  computed: {},
  methods: {}
}, {info: {"components":{"list":{"path":"..\\components\\wepy-list"}},"on":{}}, handlers: {}, models: {} });